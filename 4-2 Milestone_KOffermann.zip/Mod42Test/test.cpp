// Uncomment the next line to use precompiled headers
#include "pch.h"

// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
// 


// Name: Kerrian Offermann
// Class: CS-405 Secure Coding
// 4-2 Milestone: Unit Testing



// the global test environment setup and tear down
// you should not need to change anything here

class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};


// create our test class to house shared data between tests
// you should not need to change anything here

class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called


TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}


// Test that a collection is empty when created.

TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */


TEST_F(CollectionTest, AlwaysFail)
{
    FAIL();
}


// DONE: Create a test to verify adding a single value to an empty collection

TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // is the collection empty?
    // if empty, the size must be 0

    add_entries(1);

    // is the collection still empty?
    // if not empty, what must the size be?

}

// DONE: Create a test to verify adding five values to collection


TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    add_entries(5);

    // Five entries added
}


// DONE: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries

TEST_F(CollectionTest, VerifyMaxSize)
{
    add_entries(10); // 10 entries are added to the collection

    ASSERT_TRUE(collection->max_size() >= 0); // This statement is true which will lead to a postitive test
    ASSERT_TRUE(collection->max_size() >= 1); // This statement is true which will lead to a postitive test
    ASSERT_TRUE(collection->max_size() >= 5); // This statement is true which will lead to a postitive test
    ASSERT_TRUE(collection->max_size() >= 10); // This statement is true which will lead to a postitive test
    
}


// DONE: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries

TEST_F(CollectionTest, VerifyCapacity)
{
    add_entries(10); // 10 entries added to verify the capacity

    ASSERT_TRUE(collection->capacity() >= 0); // This statement is true which will lead to a postitive test
    ASSERT_TRUE(collection->capacity() >= 1); // This statement is true which will lead to a postitive test
    ASSERT_TRUE(collection->capacity() >= 5); // This statement is true which will lead to a postitive test
    ASSERT_TRUE(collection->capacity() >= 10); // This statement is true which will lead to a postitive test
}

// DONE: Create a test to verify resizing increases the collection

TEST_F(CollectionTest, VerifyResizeIncrease)
{
    add_entries(15);
    int initSize = collection->size(); // The initial size has 1 entry

    collection->resize(50); // The collection is resized to 50

    ASSERT_TRUE(collection->size() > initSize); // There will be a positive test since the current size of 50 is > the initial size of 1
}

// DONE: Create a test to verify resizing decreases the collection

TEST_F(CollectionTest, VerifyResizeDecrease)
{
    // Follows the same principle of the previous test but in reverse
    // We start with 50 and then drop to 15 this time
    // So, now it is true that the collection size is small than the starting size of 50 entries

    add_entries(50);
    int initSize = collection->size();

    collection->resize(15);

    ASSERT_TRUE(collection->size() < initSize);
}


// DONE: Create a test to verify resizing decreases the collection to zero

TEST_F(CollectionTest, VerifyResizeDecreaseToZero)
{
    add_entries(15);
    int initSize = collection->size();

    collection->resize(0); 

    ASSERT_TRUE(collection->size() == 0); 
    // Our collection is resized to 0 after starting with 15 entries
    // There will be a postive test since it is true that the collection is now equal to zero
}

// DONE: Create a test to verify clear erases the collection
TEST_F(CollectionTest, VerifyClear)
{
    add_entries(15);

    collection->clear();
    ASSERT_TRUE(collection->size() == 0);

    // Clear erases all entries in a collection; therefore, after the 15 entries are added initially, clearing drops it to zero.
    // Asserting that the collection size is equal to zero is true will lead to a positive test
}


// DONE: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, VerifyErase)
{
    add_entries(15);

    collection->erase(collection->begin(), collection->end());
    ASSERT_TRUE(collection->size() == 0);

    // The entire collection is erased, so the size will be zero which can be asserted as true
    // For a positive test
}

// DONE: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, VerifyCapacityIncreaseNotSize)
{
    add_entries(15); // Our collection size is now 15

    int initCapacity = collection->capacity();
    int initSize = collection->size();

    collection->reserve(20); // Our capacity is set to 20

    ASSERT_TRUE(collection->size() == initSize); // The collection will be true to the amount set for entries
    ASSERT_TRUE(collection->capacity() > initCapacity); // The capacity will be true to the amount set for it
}

// DONE: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test

TEST_F(CollectionTest, VerifyOutOfBounds)
{
    std::vector<int> vector(15); // Our vector is set to 15
    EXPECT_THROW(vector.at(20), std::out_of_range); 
    // An exception should be thrown because 20 will be out of bounds for a vector of 15
}



// DONE: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative


// DONE -- Negative Test 1: Test to verify when there are more entries then there are spaces in the collection

TEST_F(CollectionTest, VerifyMoreEntriesThanSize)
{
    add_entries(25); // 25 entries are added to the collection

    int initSize = collection->size();
    collection->resize(15); // The collection is resized to only hold 15 entries

    ASSERT_TRUE(collection->size() > initSize); 
    // There will be a negative test because this statement is not true
    // The current collection size is not large enough for the number of entries
}

// DONE -- Negative Test 2: Test to verify that a failure is returned if entries exceed the max size

TEST_F(CollectionTest, VerifyMaxSizeAccuracy)
{
    add_entries(10); // Ten entries are being added to a collection

    ASSERT_TRUE(collection->max_size() < collection->size());  
    // The test will return as false instead of true because the max_size is larger than the collection size
}


// DONE -- Positive Test 1: Test to verify that a failure is returned if entries exceed the max size -- but with expect false

TEST_F(CollectionTest, VerifyMaxSizeAccuracy_ExpectFalse)
{
    add_entries(10);
    EXPECT_FALSE(collection->max_size() == 9); // Test if the max size is accurate by using an EXPECT_FALSE statement
}

// DONE -- Positive Test 2: Test that the collection size is equal to the amount of entries added to it

TEST_F(CollectionTest, VerifySizeMatchesEntries)
{
    collection->clear();
    
    add_entries(15);
    ASSERT_TRUE(collection->size() == 15); // Verify if the size is accurate to the entries being added to the collection
    add_entries(5);
    ASSERT_TRUE(collection->size() == 20); // Verify if the size is accurate to the entries being added to the collection
    add_entries(30);
    ASSERT_TRUE(collection->size() == 50); // Verify if the size is accurate to the entries being added to the collection
}